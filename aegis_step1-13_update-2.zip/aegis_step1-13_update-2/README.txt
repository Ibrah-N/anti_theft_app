Aegis / VigilX — New Vehicle Controls (Steps 1-13)
====================================================

WHAT'S IN THIS ZIP
-------------------
This zip mirrors your repo's folder structure. It contains ONLY the files
that were changed or added for Steps 1-13 (new vehicle controls: arm/disarm,
door lock, mirror fold, engine start, AC). Extracting it into the ROOT of
your local anti_theft_app clone will overwrite exactly those 13 files and
add 1 new file — nothing else in your repo is touched.

Changed files (13):
  backend/alembic/versions/28003cc59777_add_vehicle_control_columns.py
  backend/app/models/vehicle.py
  backend/app/routes/vehicle.py
  backend/app/schemas/vehicle.py
  backend/app/services/mqtt_handlers.py
  backend/app/services/mqtt_service.py
  backend/simulator.py
  lib/data/models/vehicle_model.dart
  lib/data/providers/vehicle_provider.dart
  lib/data/services/api_service.dart
  lib/data/services/websocket_service.dart
  lib/presentation/screens/home/home_screen.dart
  lib/presentation/screens/vehicle/vehicle_screen.dart

New file (1):
  lib/presentation/widgets/vehicle/control_button.dart

CHANGES.diff is included so you can review every change before applying,
without needing to extract anything.

HOW TO APPLY LOCALLY
---------------------
1. Move/copy this zip into the root folder of your LOCAL anti_theft_app clone
   (the same folder that contains "backend/" and "lib/").
2. Make sure your local repo is clean and up to date first:
       cd ~/anti_theft_app        (or wherever your local clone lives)
       git status                 (should say "nothing to commit")
       git pull origin main
3. Unzip directly into that folder, overwriting in place:
       unzip -o aegis_step1-13_update.zip
   (-o = overwrite without prompting. This is safe here because you just
   confirmed step 2 above, so nothing is being clobbered by surprise.)
4. Confirm what changed:
       git status
       git diff --stat
   You should see the 13 modified files + 1 new file listed above.

RUN LOCALLY BEFORE PUSHING (recommended)
------------------------------------------
Backend:
       cd backend
       source venv/bin/activate      (if you use a venv)
       pip install -r requirements.txt
       alembic upgrade head          # applies the new columns to your LOCAL db
       # then run/import your FastAPI app briefly to catch import errors,
       # and/or run: pytest

Flutter:
       flutter pub get
       flutter analyze               # I could not run this myself — please do
       flutter run                   # smoke test ARM/DISARM, lock, mirrors, AC

PUSH TO YOUR REPO
-------------------
       git add -A
       git commit -m "Add vehicle controls: arm/disarm, lock, mirrors, start, AC"
       git push origin main

DEPLOY TO SERVER (per your existing flow)
--------------------------------------------
       ssh -i vigilx_k.pem root@47.236.73.110
       cd ~/anti_theft_app
       git stash               # in case the server has local edits
       git pull origin main
       cd backend
       source venv/bin/activate           (if applicable)
       alembic upgrade head                # <-- IMPORTANT: not run by systemctl restart
       cd ..
       sudo systemctl restart vigilx
       sudo systemctl status vigilx        # confirm it came up clean
       journalctl -u vigilx -f             # tail logs, watch MQTT reconnect + ack subscribe

Then run backend/simulator.py (updated in this change set) against the
server broker to end-to-end test: arm/disarm, lock/unlock, all 4 mirrors,
start engine, AC — and confirm each ACK round-trips into the DB, WebSocket,
and the app UI. That's Step 15.
